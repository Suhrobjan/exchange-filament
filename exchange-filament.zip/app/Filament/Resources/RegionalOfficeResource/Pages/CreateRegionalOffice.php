<?php

namespace App\Filament\Resources\RegionalOfficeResource\Pages;

use App\Filament\Resources\RegionalOfficeResource;
use Filament\Resources\Pages\CreateRecord;

class CreateRegionalOffice extends CreateRecord
{
    protected static string $resource = RegionalOfficeResource::class;
}
