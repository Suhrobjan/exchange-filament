<?php

namespace App\Filament\Resources\TradeEventResource\Pages;

use App\Filament\Resources\TradeEventResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateTradeEvent extends CreateRecord
{
    protected static string $resource = TradeEventResource::class;
}
