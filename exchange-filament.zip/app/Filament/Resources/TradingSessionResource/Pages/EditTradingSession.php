<?php

namespace App\Filament\Resources\TradingSessionResource\Pages;

use App\Filament\Resources\TradingSessionResource;
use Filament\Resources\Pages\EditRecord;

class EditTradingSession extends EditRecord
{
    protected static string $resource = TradingSessionResource::class;
}
