<?php

use Livewire\Component;

new class extends Component
{
    //
};
?>

<div>
    {{-- It always seems impossible until it is done. - Nelson Mandela --}}
</div>