<?php if (isset($component)) { $__componentOriginal165f8e34452936f6da18fceb86497519 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal165f8e34452936f6da18fceb86497519 = $attributes; } ?>
<?php $component = App\View\Components\App::resolve(['title' => t('pages.news_title') . ' — ' . t('footer.company_name')] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\App::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    
    <section class="bg-[#0a1628] border-b border-white/5 py-16 relative overflow-hidden">
        <div class="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-emerald-500/20 to-transparent">
        </div>
        <div class="container-exchange relative z-10">
            <h1 class="text-4xl lg:text-5xl font-black text-white mb-4 tracking-tight"><?php echo e(t('common.news')); ?></h1>
            <p class="text-slate-300 text-lg max-w-2xl"><?php echo e(t('pages.news_subtitle')); ?></p>
        </div>
    </section>

    
    
    <section class="py-20 bg-[#0a1628]">
        <div class="container-exchange">
            <div class="grid grid-cols-1 lg:grid-cols-4 gap-12">
                
                <div class="lg:col-span-3">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($currentCategory)): ?>
                        <div class="mb-8 flex items-center justify-between">
                            <h2 class="text-2xl font-bold text-white">
                                <?php echo e(t('common.category')); ?>: <span
                                    class="text-emerald-400"><?php echo e($currentCategory->name); ?></span>
                            </h2>
                            <a href="<?php echo e(route('news')); ?>" class="text-slate-400 hover:text-white text-sm transition-colors">
                                &larr; <?php echo e(t('home.all_news')); ?>

                            </a>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($news->isEmpty()): ?>
                        <div class="bg-white/5 rounded-3xl p-12 text-center border border-white/5">
                            <p class="text-slate-500 text-lg"><?php echo e(t('common.no_news')); ?></p>
                        </div>
                    <?php else: ?>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                <article
                                    class="group relative bg-white/5 border border-white/5 rounded-3xl overflow-hidden hover:bg-white/10 hover:border-emerald-500/30 transition-all duration-500 hover:-translate-y-2 flex flex-col h-full">
                                    <div class="relative aspect-[16/10] overflow-hidden shrink-0">
                                        <img src="<?php echo e($article->image ? Storage::url($article->image) : 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=500&fit=crop'); ?>"
                                            alt="<?php echo e($article->title); ?>"
                                            class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 opacity-80 group-hover:opacity-100">

                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($article->category): ?>
                                            <div class="absolute top-4 left-4">
                                                <span
                                                    class="px-3 py-1 bg-emerald-500 text-white text-[10px] font-black uppercase tracking-widest rounded-full">
                                                    <?php echo e($article->category->name); ?>

                                                </span>
                                            </div>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </div>

                                    <div class="p-8 flex flex-col flex-grow">
                                        <div
                                            class="flex items-center gap-3 text-slate-500 text-xs font-bold uppercase tracking-widest mb-4">
                                            <?php echo e($article->published_at?->format('d.m.Y') ?: $article->created_at->format('d.m.Y')); ?>

                                        </div>

                                        <h2
                                            class="text-xl font-bold text-white mb-4 leading-snug group-hover:text-emerald-400 transition-colors line-clamp-2">
                                            <a href="<?php echo e(route('news.show', $article->slug)); ?>">
                                                <?php echo e($article->title); ?>

                                            </a>
                                        </h2>

                                        <p class="text-slate-300 text-sm leading-relaxed line-clamp-3 mb-6 flex-grow">
                                            <?php echo e($article->excerpt); ?>

                                        </p>

                                        <a href="<?php echo e(route('news.show', $article->slug)); ?>"
                                            class="inline-flex items-center gap-2 text-emerald-400 text-xs font-black uppercase tracking-widest group-hover:gap-4 transition-all mt-auto">
                                            <?php echo e(t('common.read_full')); ?>

                                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M17 8l4 4m0 0l-4 4m4-4H3" />
                                            </svg>
                                        </a>
                                    </div>
                                </article>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </div>

                        
                        <div class="mt-16">
                            <?php echo e($news->appends(request()->query())->links('pagination::tailwind')); ?>

                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                
                <div class="lg:col-span-1 space-y-8">
                    
                    <div class="bg-white/5 border border-white/5 rounded-3xl p-6">
                        <h3 class="text-white font-bold text-lg mb-4"><?php echo e(t('common.search')); ?></h3>
                        <form action="<?php echo e(route('search')); ?>" method="GET" class="relative">
                            <input type="text" name="q" placeholder="<?php echo e(t('common.search_placeholder')); ?>"
                                class="w-full bg-white/10 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-colors">
                            <button type="submit" class="absolute right-3 top-3 text-slate-500 hover:text-white">
                                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                                </svg>
                            </button>
                        </form>
                    </div>

                    
                    <div class="bg-white/5 border border-white/5 rounded-3xl p-6">
                        <h3 class="text-white font-bold text-lg mb-4"><?php echo e(t('common.categories')); ?></h3>
                        <ul class="space-y-2">
                            <li>
                                <a href="<?php echo e(route('news')); ?>"
                                    class="flex items-center justify-between text-slate-400 hover:text-emerald-400 transition-colors group <?php echo e(!request('category') ? 'text-emerald-400' : ''); ?>">
                                    <span><?php echo e(t('home.all_news')); ?></span>
                                </a>
                            </li>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                <li>
                                    <a href="<?php echo e(route('news', ['category' => $category->slug])); ?>"
                                        class="flex items-center justify-between text-slate-400 hover:text-emerald-400 transition-colors group <?php echo e(request('category') == $category->slug ? 'text-emerald-400' : ''); ?>">
                                        <span><?php echo e($category->name); ?></span>
                                        <span
                                            class="bg-white/10 text-xs px-2 py-0.5 rounded-full group-hover:bg-emerald-500/20 group-hover:text-emerald-400 transition-colors">
                                            <?php echo e($category->news_count); ?>

                                        </span>
                                    </a>
                                </li>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </ul>
                    </div>

                    
                    <div class="bg-white/5 border border-white/5 rounded-3xl p-6">
                        <h3 class="text-white font-bold text-lg mb-4"><?php echo e(t('home.announcements')); ?></h3>
                        <div class="space-y-4">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $latestAnnouncements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $announcement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                <div class="group">
                                    <div class="text-[10px] text-emerald-500 font-bold uppercase tracking-widest mb-1">
                                        <?php echo e($announcement->published_at?->format('d.m.Y')); ?>

                                    </div>
                                    <a href="<?php echo e(route('announcements.show', $announcement->slug)); ?>"
                                        class="text-slate-300 hover:text-white font-medium text-sm transition-colors line-clamp-2">
                                        <?php echo e($announcement->title); ?>

                                    </a>
                                </div>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </div>
                        <a href="<?php echo e(route('announcements')); ?>"
                            class="inline-block mt-4 text-xs font-bold text-slate-500 hover:text-emerald-400 uppercase tracking-widest transition-colors">
                            <?php echo e(t('home.all_announcements')); ?> &rarr;
                        </a>
                    </div>

                    
                    <div class="bg-gradient-to-br from-emerald-600 to-teal-700 rounded-3xl p-6 text-center">
                        <svg class="w-10 h-10 text-white/80 mx-auto mb-3" fill="none" stroke="currentColor"
                            viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                        </svg>
                        <h3 class="text-white font-bold text-lg mb-2"><?php echo e(t('common.subscription')); ?></h3>
                        <p class="text-emerald-100 text-sm mb-4"><?php echo e(t('common.subscribe_desc')); ?></p>
                        <form action="#" class="space-y-2">
                            <input type="email" placeholder="<?php echo e(t('common.your_email')); ?>"
                                class="w-full bg-white/20 border-none placeholder-emerald-200 text-white rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-white/50">
                            <button
                                class="w-full bg-white text-emerald-700 font-bold text-sm py-2 rounded-xl hover:bg-emerald-50 transition-colors"><?php echo e(t('common.subscribe')); ?></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal165f8e34452936f6da18fceb86497519)): ?>
<?php $attributes = $__attributesOriginal165f8e34452936f6da18fceb86497519; ?>
<?php unset($__attributesOriginal165f8e34452936f6da18fceb86497519); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal165f8e34452936f6da18fceb86497519)): ?>
<?php $component = $__componentOriginal165f8e34452936f6da18fceb86497519; ?>
<?php unset($__componentOriginal165f8e34452936f6da18fceb86497519); ?>
<?php endif; ?><?php /**PATH D:\laragon\www\exchange-filament\resources\views/pages/news/index.blade.php ENDPATH**/ ?>