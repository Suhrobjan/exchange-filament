<?php if (isset($component)) { $__componentOriginal165f8e34452936f6da18fceb86497519 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal165f8e34452936f6da18fceb86497519 = $attributes; } ?>
<?php $component = App\View\Components\App::resolve(['title' => $announcement->title . ' — ' . t('footer.company_name')] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\App::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    
    <div class="fixed inset-0 bg-[#0a1628] pointer-events-none z-0">
        <div class="absolute top-0 left-1/3 w-1/2 h-1/2 bg-blue-500/5 blur-[120px] rounded-full"></div>
    </div>

    
    <section class="relative z-10 pt-12 pb-16">
        <div class="container-exchange">
            <nav class="flex items-center gap-3 text-xs font-bold uppercase tracking-widest mb-8">
                <a href="/" class="text-slate-500 hover:text-emerald-400 transition-colors"><?php echo e(t('common.home')); ?></a>
                <svg class="w-3 h-3 text-slate-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M9 5l7 7-7 7" />
                </svg>
                <a href="<?php echo e(route('announcements')); ?>"
                    class="text-slate-500 hover:text-emerald-400 transition-colors"><?php echo e(t('pages.announcements')); ?></a>
                <svg class="w-3 h-3 text-slate-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M9 5l7 7-7 7" />
                </svg>
                <span class="text-emerald-400 truncate max-w-[200px]"><?php echo e($announcement->title); ?></span>
            </nav>

            <div class="max-w-4xl">
                <div class="flex items-center gap-4 mb-6">
                    <?php
                        $colorClass = match ($announcement->type) {
                            'warning' => 'bg-orange-500/10 text-orange-400',
                            'urgent' => 'bg-rose-500/10 text-rose-400',
                            default => 'bg-blue-500/10 text-blue-400',
                        };
                        $label = match ($announcement->type) {
                            'warning' => t('common.attention'),
                            'urgent' => t('common.urgent'),
                            default => t('common.info'),
                        };
                    ?>
                    <span
                        class="px-3 py-1 <?php echo e($colorClass); ?> text-[10px] font-black uppercase tracking-widest rounded-full"><?php echo e($label); ?></span>
                    <time class="text-slate-500 text-sm font-medium">
                        <?php echo e($announcement->published_at?->format('d.m.Y') ?: $announcement->created_at->format('d.m.Y')); ?>

                    </time>
                </div>
                <h1 class="text-4xl lg:text-5xl font-black text-white leading-tight tracking-tight mb-8">
                    <?php echo e($announcement->title); ?>

                </h1>
            </div>
        </div>
    </section>

    
    <section class="relative z-10 pb-24">
        <div class="container-exchange">
            <div class="max-w-4xl bg-white/5 border border-white/5 rounded-[2.5rem] p-8 lg:p-12 backdrop-blur-xl">
                <div class="prose prose-invert prose-emerald max-w-none text-slate-200
                    prose-headings:text-white prose-headings:font-black prose-headings:tracking-tight
                    prose-p:text-slate-200 prose-p:leading-relaxed prose-p:text-lg
                    prose-a:text-emerald-400 prose-a:no-underline hover:prose-a:text-emerald-300
                    prose-strong:text-white prose-ul:text-slate-200 prose-li:my-2">
                    <?php echo $announcement->content; ?>

                </div>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($announcement->expires_at): ?>
                    <div class="mt-12 p-6 rounded-2xl bg-white/5 border border-white/5 flex items-center gap-4">
                        <svg class="w-6 h-6 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <p class="text-slate-500 text-sm"><?php echo e(t('common.announcement_valid_until')); ?> <span
                                class="text-white font-bold"><?php echo e($announcement->expires_at->format('d.m.Y')); ?></span></p>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>

            <div class="mt-12">
                <a href="<?php echo e(route('announcements')); ?>"
                    class="inline-flex items-center gap-2 text-emerald-400 text-xs font-black uppercase tracking-widest hover:gap-4 transition-all">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M7 16l-4-4m0 0l4-4m-4 4h18" />
                    </svg>
                    <?php echo e(t('common.back_to_announcements')); ?>

                </a>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal165f8e34452936f6da18fceb86497519)): ?>
<?php $attributes = $__attributesOriginal165f8e34452936f6da18fceb86497519; ?>
<?php unset($__attributesOriginal165f8e34452936f6da18fceb86497519); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal165f8e34452936f6da18fceb86497519)): ?>
<?php $component = $__componentOriginal165f8e34452936f6da18fceb86497519; ?>
<?php unset($__componentOriginal165f8e34452936f6da18fceb86497519); ?>
<?php endif; ?><?php /**PATH D:\laragon\www\exchange-filament\resources\views/pages/announcement-show.blade.php ENDPATH**/ ?>