# Frontend Design Plan — Exchange-Filament

## Обзор проекта

Миграция frontend сайта "Республиканская универсальная агропромышленная биржа" с Statamic Antlers на Laravel Blade с Livewire.

---

## 🎨 Дизайн-система

### Цветовая палитра

| Назначение | Цвет | HEX | Применение |
|------------|------|-----|------------|
| **Primary** | Темно-синий | `#0f172a` - `#1e3a5f` | Header, Hero, Footer |
| **Accent** | Изумрудный | `#10B981` | Кнопки, тикеры роста |
| **Danger** | Красный | `#EF4444` | Тикеры падения, предупреждения |
| **Neutral** | Slate | `#f8fafc` - `#1e293b` | Фоны, текст |

### Типографика

- **Заголовки**: Inter, 700-800, 24-48px
- **Тело текста**: Inter, 400, 14-16px
- **Моноширинный** (цены): JetBrains Mono, 14-18px

---

## 📄 Структура страниц

### 1. Главная (home)
- TOP BAR (языки, телефон, соцсети)
- QUOTES TICKER BAR (бегущая строка)
- HEADER (лого, навигация, поиск)
- HERO SECTION со статистикой
- COMMODITIES CAROUSEL
- NEWS & ANNOUNCEMENTS
- ASSOCIATIONS & PARTNERS
- TRADING CALENDAR BANNER
- MOBILE APP PROMO
- FOOTER

### 2. Котировки (quotes)
- Таблица котировок с фильтрами
- Realtime обновления (Livewire polling)

### 3. Новости (news)
- Список новостей с пагинацией
- Страница новости

### 4. О бирже (about)
- История, миссия, структура

### 5. Аккредитация (accreditation)
- Шаги аккредитации
- Документы

### 6. Брокеры (brokers)
- Список аккредитованных брокеров

---

## 🛠️ Технологии

| Технология | Назначение |
|------------|------------|
| **Laravel 12** | Backend framework |
| **Blade** | Серверный шаблонизатор |
| **Livewire 3** | Realtime компоненты |
| **TailwindCSS** | Стилизация |
| **Alpine.js** | Интерактивность |
| **Vite** | Сборка assets |

---

## 📁 Файловая структура

```
resources/views/
├── layouts/app.blade.php
├── components/
│   ├── header.blade.php
│   ├── footer.blade.php
│   ├── topbar.blade.php
│   └── accessibility-panel.blade.php
├── pages/
│   ├── home.blade.php
│   ├── news/, quotes/
│   ├── about.blade.php
│   ├── accreditation.blade.php
│   └── contacts.blade.php
└── livewire/
    └── quotes-ticker.blade.php
```
